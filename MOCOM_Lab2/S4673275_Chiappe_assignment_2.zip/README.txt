Assignment 1, MOCOM lab1 2023

Students: 
Alberto Bono,  	S4673275
Andrea Chiappe,	S3962994
Simone Lombardi	S6119159

All the students will submitt the project on aulaweb, but the report and the matlab code is the same.
